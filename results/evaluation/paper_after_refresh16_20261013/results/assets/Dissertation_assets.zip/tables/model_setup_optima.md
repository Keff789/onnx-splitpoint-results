# Model/setup split optima

Fastest and minimum-energy observed splits within each model/setup/runner. Candidate counts describe the measured search space. Q is the existing dataset metric in percent: Top-1 for classifiers and COCO mAP@[.50:.95] for detectors. These metrics are not pooled. Shared optima are one point; all choices are retrospective. Energy is host-inclusive mJ/image.

| Runner | Model | Setup | Candidates | Fastest cut | FPS | mJ/image | Q (%) | Min-energy cut | FPS | mJ/image | Q (%) | Same point |
|---|---|---|---:|---|---:|---:|---:|---|---:|---:|---:|---|
| Native | MobileNetV3-L (Top-1) | DeepX | 17 | b027 | 770 | 27.03 | 72.18 | b135 | 643 | 25.37 | 72.02 | no |
| Native | MobileNetV3-L (Top-1) | H10 | 17 | b078 | 1172 | 20.09 | 67.10 | b085 | 1140 | 18.36 | 67.58 | no |
| Native | MobileNetV3-L (Top-1) | H8 | 17 | b027 | 993 | 23.01 | 71.58 | b027 | 993 | 23.01 | 71.58 | yes |
| Native | RegNet-X 1.6GF (Top-1) | DeepX | 20 | b052 | 403 | 59.52 | 78.78 | b052 | 403 | 59.52 | 78.78 | yes |
| Native | RegNet-X 1.6GF (Top-1) | H10 | 20 | b123 | 1367 | 15.83 | 79.16 | b123 | 1367 | 15.83 | 79.16 | yes |
| Native | RegNet-X 1.6GF (Top-1) | H8 | 20 | b073 | 618 | 41.73 | 77.76 | b073 | 618 | 41.73 | 77.76 | yes |
| Native | ResNet-50 (Top-1) | DeepX | 19 | b002 | 444 | 62.04 | 80.50 | b119 | 332 | 49.86 | 80.52 | no |
| Native | ResNet-50 (Top-1) | H10 | 19 | b095 | 1100 | 29.46 | 80.16 | b095 | 1100 | 29.46 | 80.16 | yes |
| Native | ResNet-50 (Top-1) | H8 | 19 | b038 | 581 | 49.92 | 80.24 | b060 | 570 | 45.17 | 80.18 | no |
| Native | YOLO11l (mAP) | DeepX | 3 | b062 | 49 | 546.00 | 46.46 | b062 | 49 | 546.00 | 46.46 | yes |
| Native | YOLO11l (mAP) | H10 | 3 | b120 | 53 | 555.75 | 45.55 | b120 | 53 | 555.75 | 45.55 | yes |
| Native | YOLO11l (mAP) | H8 | 3 | b120 | 44 | 555.17 | 45.89 | b120 | 44 | 555.17 | 45.89 | yes |
| Native | YOLO26m (mAP) | DeepX | 3 | b043 | 61 | 429.67 | 44.81 | b038 | 60 | 428.82 | 44.78 | no |
| Native | YOLO26m (mAP) | H10 | 3 | b043 | 110 | 319.65 | 43.66 | b043 | 110 | 319.65 | 43.66 | yes |
| Native | YOLO26m (mAP) | H8 | 3 | b038 | 79 | 360.60 | 43.66 | b043 | 79 | 355.99 | 43.64 | no |
| Native | YOLO26s (mAP) | DeepX | 3 | b021 | 114 | 217.63 | 40.02 | b021 | 114 | 217.63 | 40.02 | yes |
| Native | YOLO26s (mAP) | H10 | 3 | b021 | 182 | 168.51 | 39.21 | b021 | 182 | 168.51 | 39.21 | yes |
| Native | YOLO26s (mAP) | H8 | 3 | b021 | 187 | 157.65 | 39.18 | b021 | 187 | 157.65 | 39.18 | yes |
| Native | YOLOv7 (mAP) | DeepX | 3 | b044 | 49 | 532.09 | 45.97 | b044 | 49 | 532.09 | 45.97 | yes |
| Native | YOLOv7 (mAP) | H10 | 3 | b044 | 70 | 455.36 | 45.78 | b044 | 70 | 455.36 | 45.78 | yes |
| Native | YOLOv7 (mAP) | H8 | 3 | b066 | 113 | 330.14 | 45.74 | b066 | 113 | 330.14 | 45.74 | yes |
| Generic | MobileNetV3-L (Top-1) | DeepX | 17 | b056 | 810 | 25.22 | 72.28 | b056 | 810 | 25.22 | 72.28 | yes |
| Generic | MobileNetV3-L (Top-1) | H10 | 17 | b027 | 419 | 46.26 | 72.22 | b027 | 419 | 46.26 | 72.22 | yes |
| Generic | MobileNetV3-L (Top-1) | H8 | 17 | b027 | 524 | 46.33 | 71.58 | b019 | 494 | 45.53 | 71.60 | no |
| Generic | RegNet-X 1.6GF (Top-1) | DeepX | 20 | b052 | 412 | 59.08 | 78.78 | b052 | 412 | 59.08 | 78.78 | yes |
| Generic | RegNet-X 1.6GF (Top-1) | H10 | 20 | b052 | 348 | 69.33 | 77.82 | b080 | 309 | 67.59 | 78.00 | no |
| Generic | RegNet-X 1.6GF (Top-1) | H8 | 20 | b066 | 375 | 65.89 | 78.04 | b066 | 375 | 65.89 | 78.04 | yes |
| Generic | ResNet-50 (Top-1) | DeepX | 19 | b002 | 463 | 61.94 | 80.50 | b119 | 340 | 50.88 | 80.52 | no |
| Generic | ResNet-50 (Top-1) | H10 | 19 | b002 | 303 | 82.33 | 80.20 | b002 | 303 | 82.33 | 80.20 | yes |
| Generic | ResNet-50 (Top-1) | H8 | 19 | b002 | 436 | 74.53 | 80.14 | b060 | 346 | 71.36 | 80.18 | no |
| Generic | YOLO11l (mAP) | DeepX | 3 | b062 | 47 | 568.32 | 46.46 | b062 | 47 | 568.32 | 46.46 | yes |
| Generic | YOLO11l (mAP) | H10 | 3 | b003 | 30 | 829.21 | 45.64 | b120 | 27 | 811.74 | 45.55 | no |
| Generic | YOLO11l (mAP) | H8 | 3 | b120 | 43 | 573.88 | 45.89 | b120 | 43 | 573.88 | 45.89 | yes |
| Generic | YOLO26m (mAP) | DeepX | 3 | b038 | 64 | 423.95 | 44.78 | b043 | 64 | 417.70 | 44.81 | no |
| Generic | YOLO26m (mAP) | H10 | 3 | b038 | 52 | 485.93 | 43.67 | b043 | 52 | 483.01 | 43.66 | no |
| Generic | YOLO26m (mAP) | H8 | 3 | b043 | 79 | 362.35 | 43.64 | b043 | 79 | 362.35 | 43.64 | yes |
| Generic | YOLO26s (mAP) | DeepX | 3 | b021 | 119 | 213.84 | 40.02 | b021 | 119 | 213.84 | 40.02 | yes |
| Generic | YOLO26s (mAP) | H10 | 3 | b021 | 74 | 296.28 | 39.21 | b021 | 74 | 296.28 | 39.21 | yes |
| Generic | YOLO26s (mAP) | H8 | 3 | b021 | 137 | 190.39 | 39.18 | b038 | 134 | 190.30 | 39.16 | no |
| Generic | YOLOv7 (mAP) | DeepX | 3 | b044 | 50 | 549.51 | 45.97 | b044 | 50 | 549.51 | 45.97 | yes |
| Generic | YOLOv7 (mAP) | H10 | 3 | b044 | 47 | 582.19 | 45.78 | b044 | 47 | 582.19 | 45.78 | yes |
| Generic | YOLOv7 (mAP) | H8 | 3 | b066 | 47 | 548.07 | 45.74 | b066 | 47 | 548.07 | 45.74 | yes |
