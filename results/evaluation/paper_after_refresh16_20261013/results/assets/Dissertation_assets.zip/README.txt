Dissertation assets from paper_after_refresh16_20261013.
Unpack and compile preview.tex with pdflatex; booktabs, siunitx, graphicx and longtable are required.
This is an asset preview, not a submitted or overwritten manuscript.
Read METHODS.md and CLAIM_EVIDENCE.md before final manuscript integration.
